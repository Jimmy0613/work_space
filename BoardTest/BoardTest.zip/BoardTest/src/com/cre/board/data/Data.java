package com.cre.board.data;

import java.util.ArrayList;

public class Data {
	public static ArrayList<Post> postArray;
	
	public static void loadData() {
		postArray = new ArrayList<>();
	}
	
}
