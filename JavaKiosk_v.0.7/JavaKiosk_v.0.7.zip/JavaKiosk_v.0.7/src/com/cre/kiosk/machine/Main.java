package com.cre.kiosk.machine;


public class Main {

	public static void main(String[] args) throws CloneNotSupportedException {
		Kiosk k = new Kiosk();
		k.run();
	}
}
