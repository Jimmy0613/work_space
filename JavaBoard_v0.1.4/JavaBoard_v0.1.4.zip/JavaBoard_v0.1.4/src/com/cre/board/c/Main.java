package com.cre.board.c;

public class Main {

	public static void main(String[] args) {
		Board board = new Board();
		board.run();
	}

}
