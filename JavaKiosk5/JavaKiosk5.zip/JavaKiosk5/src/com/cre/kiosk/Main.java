package com.cre.kiosk;


public class Main {

	public static void main(String[] args) {
	
		Kiosk k = new Kiosk();
		k.run();
	
	}
}
//향상된 for문
//for(String x:animals) {
//    	System.out.println(x);
//} 증감식 같은거 없어도 알아서 처음부터 끝까지 실행.